from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('', views.index, name='home'),
    path('admin_page/', views.admin_home, name='admin_page'),
    path('auction/<int:id>/', views.view_auction, name='view_auction'),
    path('auction/add/', views.add_auction, name='add_auction'),
    path('auction/update/<int:id>/', views.update_auction, name='update_auction'),
    path('auction/delete/<int:id>/', views.delete_auction, name='delete_auction'),
    # path('auction/bid/<int:id>/', views.place_bid, name='place_bid'),
    path('auction/<int:auction_id>/place_bid/', views.place_bid, name='place_bid'),
    path('auction/bid-history/', views.view_bid_history, name='view_bid_history'),
    path('user_dashboard/', views.user_dashboard, name='user_dashboard'),    
    # Authentication URLs
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),   # Custom login view
    path('logout/', views.user_logout, name='logout'), # Custom logout view

]
