from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from .models import *
from django.utils import timezone
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import login, logout, authenticate



def is_admin(user):
    return user.is_superuser

from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from django.contrib import messages

def user_login(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']

        # Authenticate the user
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            # Check if the user is an admin or a regular user
            if user.is_superuser:
                return redirect('admin_page')  # Admin dashboard page
            else:
                return redirect('user_dashboard')  # User dashboard page
        else:
            messages.error(request, "Invalid username or password!")

    return render(request, 'auction/login.html')


@login_required
def user_dashboard(request):
    # Get all active auctions (auctions that have not ended)
    active_auctions = Auction.objects.filter(ends_at__gt=timezone.now())

    return render(request, 'auction/user_dashboard.html', {
        'auctions': active_auctions,
        'now': timezone.now()  # Pass the current time for comparison in the template
    })


def user_logout(request):
    logout(request)
    return redirect('home')  # Redirect to login page after logout

def register(request):
    if request.method == "POST":
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        password2 = request.POST['password2']

        if password != password2:
            messages.error(request, "Passwords do not match!")
            return redirect('register')

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists!")
            return redirect('register')

        user = User.objects.create_user(username=username, email=email, password=password)
        login(request, user)
        messages.success(request, "Registration successful! You are now logged in.")
        return redirect('home')

    return render(request, 'auction/register.html')


def index(request):
    return render(request, 'auction/index.html')

def admin_home(request):
    auctions = Auction.objects.all()
    return render(request, 'auction/index copy.html', {'auctions': auctions})


def view_bid_history(request):
    # Get all auctions that have ended
    ended_auctions = Auction.objects.filter(ends_at__lt=timezone.now())

    # Get all bids for those auctions that have ended
    bids = Bid.objects.filter(auction__in=ended_auctions).order_by('-created_at')

    # Pass the bids and auction details to the template for rendering
    return render(request, 'auction/view_bid_history.html', {
        'bids': bids
    })

@login_required
def view_auction(request, id):
    # Get the auction by its id
    auction = get_object_or_404(Auction, id=id)

    # Get all the bids related to this auction, ordered by bid_time
    bids = auction.bids.all().order_by('-created_at')  # This works because of the related_name='bids'

    return render(request, 'auction/view_auction.html', {'auction': auction, 'bids': bids})

# Custom test function to check if the user is an admin
def is_admin(user):
    return user.is_superuser  # Assuming you're using the `is_superuser` field for admins

@user_passes_test(is_admin)
def add_auction(request):
    if request.method == "POST":
        title = request.POST['title']
        description = request.POST['description']
        starting_bid = request.POST['starting_bid']
        ends_at = request.POST['ends_at']
        
        # Create a new auction and associate it with the logged-in user
        Auction.objects.create(
            title=title,
            description=description,
            start_bid=starting_bid,
            current_bid=starting_bid,
            ends_at=ends_at,
            user=request.user  # Associate auction with the current logged-in user
        )
        return redirect('admin_page')  # Redirect to home page after the auction is created
    return render(request, 'auction/add_auction.html')

@user_passes_test(is_admin)
def update_auction(request, id):
    auction = get_object_or_404(Auction, id=id)
    if request.method == "POST":
        auction.title = request.POST['title']
        auction.description = request.POST['description']
        auction.starting_bid = request.POST['starting_bid']
        auction.ends_at = request.POST['ends_at']
        auction.save()
        return redirect('admin_page')
    return render(request, 'auction/update_auction.html', {'auction': auction})

@user_passes_test(is_admin)
def delete_auction(request, id):
    auction = get_object_or_404(Auction, id=id)
    auction.delete()
    return redirect('admin_page')


from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from .models import Auction, Bid
from django.utils import timezone

@login_required
def place_bid(request, auction_id):
    auction = get_object_or_404(Auction, id=auction_id)
    
    # Check if auction has ended
    if auction.ends_at < timezone.now():
        return JsonResponse({"error": "This auction has ended."}, status=400)

    # Handle the bid
    if request.method == 'POST':
        bid_amount = request.POST.get('bid_amount')
        bid_amount = float(bid_amount)
        
        # Validate the bid amount
        if bid_amount <= auction.current_bid:
            return JsonResponse({"error": "Bid must be higher than the current bid."}, status=400)

        # Create a new bid
        bid = Bid.objects.create(user=request.user, auction=auction, amount=bid_amount)
        
        # Update the current bid of the auction
        auction.current_bid = bid_amount
        auction.save()

        return JsonResponse({
            "message": "Bid placed successfully.",
            "current_bid": auction.current_bid,
            "new_bidder": request.user.username,
        })

    return redirect('auction_detail', auction_id=auction.id)

