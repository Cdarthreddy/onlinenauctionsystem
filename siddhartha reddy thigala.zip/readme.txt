Open Auction System - Django Web Application



Project Overview
This is an online auction platform built with Django (Python), MySQL, and Bootstrap, allowing users to:
- Buy/Sell items via bidding
- Place Bids (with real-time validation)
- Comment on Listings (discussions & inquiries)
- Secure Authentication (login, logout, registration)

Technology Stack
Backend: Django (Python)

Database: MySQL

Frontend: Bootstrap 5, Django Templates

Additional: JavaScript (form validation, live preview)

Features
User Authentication (Login, Logout, Signup)
CRUD Operations (Create, Read, Update, Delete Listings)
Bidding System (Auto-updates current price)
Admin Panel (Manage users, listings, bids)

Setup & Installation
1. Prerequisites
Python 3.8+

MySQL Server

pip (Python package manager)


2. Clone & Install Dependencies
git clone [your-repo-link]
cd auction_system


3. Configure MySQL Database

Create a MySQL database:
- CREATE DATABASE auction_db;

Update you mysql credentials
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'auction_db',
        'USER': 'your_username',
        'PASSWORD': 'your_password',
        'HOST': 'localhost',
        'PORT': '3306',
    }
}


4. Run Migrations & Start Server

python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser  # (Optional: For admin access)
python manage.py runserver


Then Visit the URL -> http://127.0.0.1:8000/


Usage
For Sellers
Login → Create Listing (Set title, description, starting bid, image).

Manage Listings (Edit/Close auctions from "My Listings").

For Buyers
Browse Listings → Place Bid (Must be higher than current price).

Add to Watchlist (Track favorite auctions).

Comment (Ask questions or discuss listings).

For Admins
Access /admin to manage users, listings, bids, and categories.

